var firstName = document.getElementById("fname").value;
var LastName = document.getElementById("lname").value;

console.log(firstName);
console.log(LastName);