import sqlite3
import pandas as pd

conn = sqlite3.connect('../exercise2/cricket.db')
c = conn.cursor()


def table_entry(table_name):
    c.execute("""CREATE TABLE IF NOT EXISTS """+table_name+""" (
        Name text,
        Team text,
        Runs_scored integer,
        Wickets_taken integer
        )""")

    c.execute("INSERT INTO "+table_name+" VALUES ('Sachin', 'India', 15000, 10)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Virat', 'India', 8000, 10)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Murali', 'Srilanka', 2000, 450)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Hayden', 'Australia', 10000, 10)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Kumble', 'India', 2000, 400)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Srinath', 'India', 1000, 300)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Shane', 'Australia', 15000, 400)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Jacques', 'SA', 11500, 200)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Jack', 'England', 5000, 50)")
    c.execute("INSERT INTO "+table_name+" VALUES ('Sydney', 'England', 1000, 100)")
    conn.commit()

def table_exists(table_name):
    c.execute(" SELECT count(Name) FROM sqlite_master WHERE type='table' AND name='"+table_name+"' ")
    if c.fetchone()[0]==1 : {
	    print('Table already exists.')
    }


def bat_grade(new_runs, team):
    if new_runs > 20000:
        return "Grade A"
    else:
        return "Grade B"

def bowl_grade(new_wickets, team):    
    if new_wickets > 400:
        return "Grade A"
    else:
        return "Grade B"

def grading(table_name, team):

    table_exists(table_name)
    table_entry(table_name)
    c.execute("SELECT Team FROM "+table_name+" WHERE Team=?",(team,))
    a = c.fetchall()
    print(a)
    if not a:
       print("Team not  in table")
       return
    else:
       print("Team in table")

    c.execute("SELECT SUM(DISTINCT Runs_scored) FROM "+table_name+" WHERE TEAM=?",(team,))
    runs = c.fetchone()
    c.execute("SELECT SUM(DISTINCT Wickets_taken) FROM "+table_name+" WHERE TEAM=?",(team,))
    wickets = c.fetchone()
    print(runs)
    print(wickets)
    new_runs = int(''.join(map(str, runs))) 
    new_wickets = int(''.join(map(str, wickets))) 
    conn.close()

    g1 = bat_grade(new_runs, team)
    g2 = bowl_grade(new_wickets, team)
    
    if g1 == "Grade A" and g2 == "Grade A":
        print("Grade A+")
    elif g1 == "Grade A" and g2 == "Grade B" or g2 == "Grade A" and g1 == "Grade B":
        print("Grade A")
    else:
        print("Grade B")


#Enter inputs(Team Name and Table Name)
def input_data():
    print("List of available team names : India, Srilanka, Australia, SA, England")
    team = input("Enter Team Name : ")
    table_name = input("Enter table name : ")

    #Calling grading function
    grading(table_name, team)

input_data()