import csv
import pandas as pd

#Create a dictionary and list as told, take input from user as to what the file name has to be
v_dict = {'apple': ['appl','appel','appal'], 'market': ['markt','markte','markat']} 
mylist = ['markat', 'boayt', 'appl', 'orng']
table_name = input("Enter your desired Table Name: ") + '.csv'

#Identify if items from the list match the key from the dictionary
def identifyKey(Dict, List, table_name):
    List=[]
    Match=[]
    for key, values in v_dict.items():
        for item in mylist:
            if item in values:
                List.append(item)
                Match.append(key)
    for item in mylist:
        if item not in List:
            List.append(item)
            Match.append(" ")
    writeToCsv(table_name, List, Match)

#Write the output to a .csv file
def writeToCsv(table_name, List, Match):
    with open(table_name, 'w', newline='') as csvfile:
        fieldnames = ['List', 'Match']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for i, j in zip(List, Match):
            writer.writerow({'List': i, 'Match': j})

#Calling identifyKey()
identifyKey(v_dict, mylist, table_name)